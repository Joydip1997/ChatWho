package com.androdude.chatwho.Mainscreen

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.widget.Toolbar
import com.androdude.chatwho.Mainscreen.Adapters.pageAdapter
import com.androdude.chatwho.R
import com.androdude.chatwho.User_Account_Actions.AccountActivity
import com.androdude.chatwho.Utils.UserOnlineStatus
import com.google.android.material.tabs.TabLayout
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.activity_chat.*
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {

    //Global Variable
    val uStatus = UserOnlineStatus()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val toolbar = findViewById<Toolbar>(R.id.toolbar1)
        setSupportActionBar(toolbar)


        val pAdapter = pageAdapter(supportFragmentManager,tab_layout.tabCount)

        viewPager.adapter=pAdapter

        viewPager.addOnPageChangeListener(TabLayout.TabLayoutOnPageChangeListener(tab_layout))


        tab_layout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener{
            override fun onTabReselected(p0: TabLayout.Tab?) {
                viewPager.currentItem=p0!!.position
                if(p0.position == 0)
                {
                    pAdapter.notifyDataSetChanged()
                }
                else if( p0.position == 1)
                {
                    pAdapter.notifyDataSetChanged()
                }
                else
                {
                    pAdapter.notifyDataSetChanged()
                }

            }

            override fun onTabUnselected(p0: TabLayout.Tab?) {

            }

            override fun onTabSelected(p0: TabLayout.Tab?) {
               viewPager.currentItem=p0!!.position
                if(p0.position == 0)
                {
                    pAdapter.notifyDataSetChanged()
                }
                else if( p0.position == 1)
                {
                    pAdapter.notifyDataSetChanged()
                }
                else
                {
                    pAdapter.notifyDataSetChanged()
                }
            }

        })


    }


    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val infalter = menuInflater
        infalter.inflate(R.menu.menu,menu)
        return super.onCreateOptionsMenu(menu)
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if(item.itemId == R.id.Logout)
        {
            FirebaseAuth.getInstance().signOut()
            startActivity(Intent(this,AccountActivity::class.java))
        }
        if(item.itemId == R.id.Settings)
        {
            startActivity(Intent(this,ProfileActivity::class.java))
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onResume() {
        super.onResume()
        uStatus.setOnline()
    }

    override fun onPause() {
        super.onPause()
        uStatus.setOffline()
    }

}
