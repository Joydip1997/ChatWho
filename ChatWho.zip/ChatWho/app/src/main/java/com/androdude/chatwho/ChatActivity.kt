package com.androdude.chatwho

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import com.androdude.chatwho.Mainscreen.Adapters.mAdapter
import com.androdude.chatwho.Model_Class.Chat
import com.androdude.chatwho.Utils.UserOnlineStatus
import com.bumptech.glide.Glide
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import kotlinx.android.synthetic.main.activity_chat.*
import java.util.*
import kotlin.collections.ArrayList


class ChatActivity : AppCompatActivity() {

    //Global Variable
    val uStatus = UserOnlineStatus()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        getSupportActionBar()!!.setDisplayShowTitleEnabled(false)
        back_icon.setOnClickListener()
        {
            onBackPressed()
        }

        //Firebase Variables
        val mUid = FirebaseAuth.getInstance().currentUser!!.uid
        val myRef = FirebaseDatabase.getInstance().getReference("messages")

        //Getting Receiver's Details
        val oUid = intent.getStringExtra("UID")
        val oUserName  = intent.getStringExtra("NAME")
        val oUserStatus = intent.getStringExtra("STATUS")
        val oUserImgURL = intent.getStringExtra("IMGURL")


        //Changing Letter To Uppercase
        val editedName = updatingName(oUserName)

        user_name_chat.setText(editedName)
        if(!(oUserImgURL.equals("default")))
        {
            Glide.with(this).load(oUserImgURL).into(user_profile_chat_image)
        }
        else
        {
            user_profile_chat_image.setBackgroundResource(R.drawable.ic_launcher_background)
        }


        //RecyclerView
        val cList = ArrayList<Chat>()
        val mAdapter = mAdapter(cList,this)
        chats_rView.adapter=mAdapter
        chats_rView.layoutManager=LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false)

        sendMessages(myRef,mUid,oUid,mAdapter)

        readMessages(myRef,mUid,oUid,cList,mAdapter)

    }

    private fun readMessages(myRef: DatabaseReference, mUid: String, oUid: String?, cList: ArrayList<Chat>, mAdapter: mAdapter) {
            myRef.child("chats").addValueEventListener(object : ValueEventListener
            {
                override fun onCancelled(p0: DatabaseError) {

                }

                override fun onDataChange(p0: DataSnapshot) {
                    cList.clear()
                    for(k in p0.children)
                    {
                        val objects = k.getValue(Chat::class.java)
                        if(objects!!.sender!!.equals(mUid) && objects.reciver!!.equals(oUid)
                            || objects.sender!!.equals(oUid) && objects.reciver!!.equals(mUid))
                        {
                            cList.add(objects)
                        }
                        mAdapter.notifyDataSetChanged()
                    }
                }

            })
    }


    private fun sendMessages(myRef: DatabaseReference, mUid: String, oUid: String?, mAdapter: mAdapter) {
        send_bttn.setOnClickListener()
        {
            if(!(messages_edit_text.text.isEmpty()))
            {
                myRef.child("chats").push().setValue(Chat(messages_edit_text.text.toString(),mUid,oUid,false))
                chats_rView.scrollToPosition(mAdapter.itemCount - 1)
                mAdapter.notifyDataSetChanged()
                messages_edit_text.setText("")
            }
        }
    }

   fun updatingName(name : String) : String
    {
        var nName = ""
        var i = 1
        while(i<name.length)
        {
            nName += name[i]
            i++
        }
        return name.get(0).toString().toUpperCase() + nName
    }


    override fun onResume() {
        super.onResume()
        uStatus.setOnline()
    }

    override fun onPause() {
        super.onPause()
        uStatus.setOffline()
    }





}
